﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _10_Warcraft2Simulator.Abstracts.Units
{
    class ACreatureMovable : ACreature, ICreatureMovable
    {
        public ACreatureMovable(Point Position, string ImageSource, Rotation Rotation,
            byte MaxHitPoints, byte HitPoints, byte Armor, Race Race)
            :base(Position, ImageSource, Rotation, MaxHitPoints, HitPoints, Armor, Race)
        {

        }

        public override System.Drawing.Point Position
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public byte MovementSpeed
        {
            get { throw new NotImplementedException(); }
        }

        public IWorld World
        {
            get { throw new NotImplementedException(); }
        }

        public void Move()
        {
            throw new NotImplementedException();
        }
    }
}
