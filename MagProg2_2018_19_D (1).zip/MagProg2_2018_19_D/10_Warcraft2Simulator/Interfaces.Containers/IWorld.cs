﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _10_Warcraft2Simulator
{
    interface IWorld
    {
        List<IGameObject> TerritoryElements { get; }
        List<ICommunity> Communities { get; }

        void Draw();
        void PlayOneRound();
    }
}
