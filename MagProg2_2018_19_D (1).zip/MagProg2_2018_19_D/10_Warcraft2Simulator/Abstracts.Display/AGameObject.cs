﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _10_Warcraft2Simulator
{
    abstract class AGameObject : IGameObject
    {
        public AGameObject(Point Position, string ImageSource)
        {
            this.Position = Position;
            this.Rotation = Rotation.NORTH;
        }
        public AGameObject(Point Position, string ImageSource, Rotation Rotation)
            :this(Position, ImageSource)
        {
            this.Rotation = Rotation;
        }

        public abstract System.Drawing.Point Position
        {
            get; set;
        }

        public abstract bool Traversable { get; }

        private string imageSource;
        public string ImageSource
        {
            private set
            {
                if (File.Exists(value))
                    imageSource = value;
                else throw new FileNotFoundException("File not found", value);
            }
            get { return imageSource; }
        }

        public Rotation Rotation
        {
            get;
            set;
        }

        public void Display(Graphics g)
        {
            Image img = Image.FromFile(ImageSource);
            switch (Rotation)
            {
                case Rotation.NORTH: break;
                case Rotation.EAST: img.RotateFlip(RotateFlipType.Rotate270FlipNone); break;
                case Rotation.SOUTH: img.RotateFlip(RotateFlipType.Rotate180FlipNone); break;
                case Rotation.WEST: img.RotateFlip(RotateFlipType.Rotate90FlipNone); break;
                default: break;
            }
            g.DrawImage(img, Position);
        }
    }
}
