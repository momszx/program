﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using System.Threading.Tasks;

namespace _04_Galaxis
{
    enum BolygoOsztaly
    {
        GAZ,
        TORPE,
        KOZET,
        EXO
    }
}
