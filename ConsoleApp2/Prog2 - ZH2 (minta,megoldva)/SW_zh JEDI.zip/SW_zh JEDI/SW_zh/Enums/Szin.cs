﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SW_zh
{
    enum Szin
    {
        KEK = 0,
        ZOLD = 1,
        LILA = 2,
        SARGA = 3,
        PIROS = 4
    }
}
