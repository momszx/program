﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SW_zh
{
    class JediRend
    {
        //private List<IErohasznalo> _jedik = new List<IErohasznalo>();
        //public List<IErohasznalo> jedik
        //{
        //    get { return _jedik; }
        //}
    }
}
