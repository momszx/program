﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SW_zh
{
    class Program
    {
        static JediRend jediRend;

        static void Main(string[] args)
        {
            jediRend = new JediRend();

            FileFeldolgozas("Jedik.csv");

            //Console.WriteLine("A Jedi rend tagjai: ");
            //foreach (var jedi in jediRend.jedik)
            //{
            //    Console.WriteLine(jedi.nev);
            //}

            //Console.WriteLine("A Jedi Anakint közelítő mesterei: ");
            //foreach (var jedi in jediRend.AnakintKozelitoMesterek)
            //{
            //    Console.WriteLine(jedi.nev);
            //}

            Console.ReadLine();
        }

        public static void FileFeldolgozas(string path)
        {
            
        }
    }
}
